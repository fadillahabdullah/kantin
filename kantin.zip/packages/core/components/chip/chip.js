export default {
  name: 'chip',
};
