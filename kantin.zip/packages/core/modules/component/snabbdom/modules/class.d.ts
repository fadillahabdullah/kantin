import { Module } from './module';
export declare type Classes = Record<string, boolean>;
export declare const classModule: Module;
export default classModule;
